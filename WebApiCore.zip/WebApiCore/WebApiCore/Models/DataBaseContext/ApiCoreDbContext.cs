﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Entities;

namespace WebApiCore.Models.DataBaseContext
{
    public class ApiCoreDbContext:DbContext
    {
        public ApiCoreDbContext(DbContextOptions<ApiCoreDbContext> options) : base(options){}
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Users> Users { get; set; }
    }
}
