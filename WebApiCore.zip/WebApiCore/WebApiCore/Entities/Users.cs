﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApiCore.Entities
{
    public class Users
    {
        [Key]
        public int Userid { get; set; }
        public string Firstname { get; set; }
        public string Middlename { get; set; }
        public string Lastname { get; set; }
        public string Emailid { get; set; }
        public string Mobilenumber { get; set; }
        public string Username { get; set; }
        //[JsonIgnore]
        public string Password { get; set; }
    }
}
