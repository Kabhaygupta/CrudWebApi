﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WebApiCore.Entities
{
    public class Employee
    {
        [Key]
        //[IgnoreDataMember]
        //[NonSerialized]
        //[JsonIgnore]
        public int Emp_Id { get; set; }
        public string First_Name { get; set; }
        public string Middle_Name { get; set; }
        public string Last_Name { get; set; }
        public string Company_Name { get; set; }
        public string Departement { get; set; }
        public string Degignation { get; set; }
        public decimal Salary { get; set; }
    }
}
