﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Entities;
using WebApiCore.IServices;
using WebApiCore.Models;
using WebApiCore.Models.DataBaseContext;

namespace WebApiCore.Servives
{
    public class EmployeeServices:IEmployeeServices
    {
        private readonly ApiCoreDbContext _dbContext;
        public EmployeeServices(ApiCoreDbContext dbcontext) 
        {
            _dbContext = dbcontext;
        }
        //public IEnumerable<Employee> GetEmployee()
        public async Task<IEnumerable<Employee>> GetEmployee()
        {          
            //var employee = await _dbContext.Employee.ToList();
            var employee = await _dbContext.Employee.ToListAsync();
            return employee;
        }

        public IEnumerable<Employee> GetEmployeeById(int id)
        {
            var employee = _dbContext.Employee.FirstOrDefault(d => d.Emp_Id == id);
#pragma warning disable CA1806 // Do not ignore method results
            _dbContext.Employee.ToList();
#pragma warning restore CA1806 // Do not ignore method results
            yield return employee;
        }

        public IEnumerable<Employee> AddEmployee(Employee employee)
        {
            if(employee !=null)
            {
                _dbContext.Employee.Add(employee);
                _dbContext.SaveChanges();
                yield return employee;
            }
            yield return null;    

        }

        public IEnumerable<Employee> UpdateEmployee(Employee employee)
        {
            _dbContext.Entry(employee).State = EntityState.Modified;
            _dbContext.SaveChanges();
            yield return employee;

            //var result = _dbContext.Employee.FirstOrDefault(e => e.Emp_Id==employee.Emp_Id);
            //if(result!=null)
            //{
            //    _dbContext.Entry(employee).State = EntityState.Modified;
            //    _dbContext.SaveChanges();
            //    yield return result;
            //}
            //yield return null;
        }

        //public IEnumerable<Employee> EditEmployeeById(int id)
        //{
        //    var employee = _dbContext.Employee.FirstOrDefault(x => x.Emp_Id == id);
        //    _dbContext.Employee.ToList();
        //    _dbContext.SaveChanges();
        //    yield return employee;
        //}

        public IEnumerable<Employee> DeleteEmployee(int id)
        {
            var employee = _dbContext.Employee.FirstOrDefault(x => x.Emp_Id == id);
            _dbContext.Entry(employee).State = EntityState.Deleted;
            _dbContext.SaveChanges();
            yield return employee;
        }
    }
}
