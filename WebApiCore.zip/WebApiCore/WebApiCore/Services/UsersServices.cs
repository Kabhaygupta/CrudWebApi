﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Entities;
using WebApiCore.IServices;
using WebApiCore.Models.DataBaseContext;

namespace WebApiCore.Services
{
    public class UsersServices:IUsersServices
    {
        private readonly ApiCoreDbContext _dbContext;
        public UsersServices(ApiCoreDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Users> Authenticate(string username, string password)
        {
            var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Username == username && x.Password == password);
            if(user==null)
            return null;

            return user;
        }

        public async  Task<IEnumerable<Users>> GetAllUsers()
        {
            var user = await _dbContext.Users.ToListAsync();
            return user;
        }
    }
}
