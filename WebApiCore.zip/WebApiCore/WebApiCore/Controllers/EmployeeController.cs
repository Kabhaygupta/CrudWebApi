﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Entities;
using WebApiCore.IServices;
using WebApiCore.Models;

namespace WebApiCore.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeServices _employeeServices;
        public EmployeeController(IEmployeeServices employeeServices)
        {
            _employeeServices = employeeServices;
        }

        //[Authorize]
        [HttpGet]
        //[Route("[action]")]
        [Route("GetEmployee")]
        //public IEnumerable<Employee> GetEmployee()
        public async Task<IActionResult> GetEmployee()
        {
            //return _employeeServices.GetEmployee();
            var result = await _employeeServices.GetEmployee();
            return Ok(result);
        }
        //[Authorize]
        [HttpGet]
        //[Route("[action]")]
        [Route("GetEmployeeById/{id}")]
        public IEnumerable<Employee> GetEmployeeById(int id)
        {
            return _employeeServices.GetEmployeeById(id);
        }

        [HttpPost] 
        [Route("AddEmployee")]
        public IEnumerable<Employee> AddEmployee(Employee employee)
        {
            return _employeeServices.AddEmployee(employee);
        }

        [HttpPut]
        [Route("UpdateEmployee")]
        public IEnumerable<Employee> UpdateEmployee(Employee employee)
        {
            return _employeeServices.UpdateEmployee(employee);
        }

        //[HttpPut]
        //[Route("EditEmployeeById/{Id}")]
        //public IEnumerable<Employee> EditEmployeeById(int id)
        //{
        //    return _employeeServices.EditEmployeeById(id);
        //}

        [HttpDelete]
        [Route("DeleteEmployee/{id}")]
        public IEnumerable<Employee> DeleteEmployee(int  id)
        {
            return _employeeServices.DeleteEmployee(id);
        }
    }
}
