﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.IServices;
using WebApiCore.Models;

namespace WebApiCore.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUsersServices _usersServices;
        public UsersController(IUsersServices usersServices)
        {
            _usersServices = usersServices;
        }

        //[AllowAnonymous]
        [HttpPost("Authenticate")]
        public async Task<IActionResult> Authenticate(AuthenticationModel authenticationModel)
        {
            //var user = await _usersServices.Authenticate(x => x.Username == username && x.Password == password);
            var user = await _usersServices.Authenticate(authenticationModel.Username, authenticationModel.Password);
            if (user == null)
                return BadRequest(new { message = "username and password is incorrect!!!" });
              
            return Ok(user);
        }

        [AllowAnonymous]
        [HttpGet]
        [Route("GetAllUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            var result = await _usersServices.GetAllUsers();
            return Ok(result);
        }
    }
}
