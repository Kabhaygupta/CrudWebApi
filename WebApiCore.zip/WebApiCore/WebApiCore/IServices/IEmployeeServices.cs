﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Entities;
using WebApiCore.Models;

namespace WebApiCore.IServices
{
    public interface IEmployeeServices
    {
        //IEnumerable<Employee> GetEmployee();
        Task<IEnumerable<Employee>> GetEmployee();
        IEnumerable<Employee> GetEmployeeById(int id);
        IEnumerable<Employee> AddEmployee(Employee employee);      
        IEnumerable<Employee> UpdateEmployee(Employee employee);
        //IEnumerable<Employee> EditEmployeeById(int id);
        IEnumerable<Employee> DeleteEmployee(int id);
    }
}
