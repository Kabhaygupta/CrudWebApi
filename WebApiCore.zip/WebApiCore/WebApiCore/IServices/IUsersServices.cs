﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Entities;

namespace WebApiCore.IServices
{
    public interface IUsersServices
    {
        Task<Users> Authenticate(string username, string password);
        Task<IEnumerable<Users>> GetAllUsers();
    }
}
